
from datetime import datetime
import re
try:
    from dateutil import parser as date_parser
    _HAS_DATEUTIL = True
except Exception:
    _HAS_DATEUTIL = False

def _normalize(s):
    import re
    return re.sub(r"\s+", " ", s.strip())

def _uniquify(seq):
    seen = set()
    out = []
    for x in seq:
        if x not in seen:
            out.append(x)
            seen.add(x)
    return out

def _find_dates(text):
    import re
    from datetime import datetime
    date_like_patterns = [
        r"\b\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}\b",
        r"\b\d{4}[\/\-.]\d{1,2}[\/\-.]\d{1,2}\b",
        r"\b\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)\w*\s+\d{2,4}\b",
        r"\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)\w*\s+\d{1,2},?\s+\d{2,4}\b",
        r"\b\d{1,2}(?:st|nd|rd|th)\s+(?:of\s+)?(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)\w*,?\s+\d{2,4}\b",
    ]
    all_spans = []
    for pat in date_like_patterns:
        for m in re.finditer(pat, text, flags=re.IGNORECASE):
            all_spans.append((m.start(), m.end(), m.group(0)))
    all_spans.sort()
    picked = []
    last_end = -1
    for s, e, val in all_spans:
        if s >= last_end:
            picked.append(val)
            last_end = e
    results = []
    for raw in picked:
        norm = None
        try:
            if _HAS_DATEUTIL:
                dt = date_parser.parse(raw, dayfirst=True, fuzzy=True)
                norm = dt.strftime("%Y-%m-%d")
            else:
                for fmt in ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d", "%d.%m.%Y", "%d %b %Y", "%b %d, %Y", "%d %B %Y"):
                    try:
                        dt = datetime.strptime(raw.replace("Sept", "Sep"), fmt)
                        norm = dt.strftime("%Y-%m-%d")
                        break
                    except Exception:
                        pass
        except Exception:
            norm = None
        results.append({"original": raw, "normalized": norm})
    unique = []
    seen = set()
    for item in results:
        key = (item["original"].lower(), item["normalized"] or "")
        if key not in seen:
            unique.append(item)
            seen.add(key)
    return unique

def extract_identifiers(email_text: str):
    import re
    if not email_text:
        return {
            "dates": [],
            "pan_numbers": [],
            "arn_numbers": [],
            "folio_numbers": [],
            "transaction_ids": [],
            "seven_digit_numbers": [],
            "client_ids": [],
        }
    text = email_text
    pan_pat = re.compile(r"\b([A-Z]{5}\d{4}[A-Z])\b", flags=re.IGNORECASE)
    pans = [m.upper() for m in pan_pat.findall(text)]
    arn_pat = re.compile(r"\bARN[\s:\-]*([0-9]{5,7})\b", flags=re.IGNORECASE)
    arns = arn_pat.findall(text)
    folio_pat = re.compile(r"\bFolio(?:\s*(?:No\.?|Number))?[\s:\-]*([A-Z0-9][A-Z0-9\-\/]{4,19})\b", flags=re.IGNORECASE)
    folios = [m.upper() for m in folio_pat.findall(text)]
    txn_leads = r"(?:Transaction|Txn|UTR|Reference|Ref)"
    txn_pat = re.compile(rf"\b{txn_leads}[\s_\-]*(?:ID|No\.?|Number)?[\s:\-]*([A-Z0-9][A-Z0-9\-]{7,29})\b", flags=re.IGNORECASE)
    txns = [m.upper() for m in txn_pat.findall(text)]
    client_pat = re.compile(r"\b(?:Client|Customer|Investor|User)[\s_\-]*(?:ID|No\.?|Number)[\s:\-]*([A-Z0-9][A-Z0-9\-]{2,19})\b", flags=re.IGNORECASE)
    client_ids = [m.upper() for m in client_pat.findall(text)]
    seven_digit_pat = re.compile(r"\b(\d{7})\b")
    seven_digits = seven_digit_pat.findall(text)
    dates = _find_dates(text)
    def _normalize(s):
        import re
        return re.sub(r"\s+", " ", s.strip())
    def _uniquify(seq):
        seen = set()
        out = []
        for x in seq:
            if x not in seen:
                out.append(x)
                seen.add(x)
        return out
    result = {
        "dates": dates,
        "pan_numbers": _uniquify([_normalize(x) for x in pans]),
        "arn_numbers": _uniquify([_normalize(x) for x in arns]),
        "folio_numbers": _uniquify([_normalize(x) for x in folios]),
        "transaction_ids": _uniquify([_normalize(x) for x in txns]),
        "seven_digit_numbers": _uniquify(seven_digits),
        "client_ids": _uniquify([_normalize(x) for x in client_ids]),
    }
    return result
